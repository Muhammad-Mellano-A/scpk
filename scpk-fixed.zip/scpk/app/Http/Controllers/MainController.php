<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Balita;

class MainController extends Controller
{
    public function index(){
      $periksa = DB::table('periksa')->get();
      return view('main-menu',['balita' => $periksa]);
    }

    public function tambah(){
      return view('tambah-balita');
    }

    public function simpan(Request $request){
      DB::table('periksa')->insert([
        'id' => $request->id,
        'nama' => $request->nama,
        'tanggal_lahir' => $request->tanggal_lahir,
        'jenis_kelamin' => $request->jenis_kelamin,
        'tanggal_periksa' => $request->tanggal_periksa,
        'berat_badan' => $request->berat_badan,
        'pola_makan' => $request->pola_makan,
        'gangguan_pencernaan' => $request->gangguan_pencernaan,
        'nutrisi_ibu' => $request->nutrisi_ibu,
        'ekonomi_ibu' => $request->ekonomi_ibu
      ]);

      return redirect('/')->with('Data berhasil ditambahkan!');
    }

    public function hapus($id){
      DB::table('periksa')-> where ('id',$id)->delete();
      return redirect('/');
    }

    public function riwayat(){
      $periksa = DB::table('periksa')->get();
      return view('riwayat',['periksa' => $periksa]);
    }
}
