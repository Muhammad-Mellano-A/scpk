<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Periksa extends Model
{
  protected $fillable = [
    'id_bayi','tanggal_periksa','berat_badan','pola_makan','gangguan_pencernaan','nutrisi_ibu','ekonomi_ibu'
  ];
  public function balita(){
    return $this->belongsTo('App\Balita');
  }
}
