<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Balita extends Model
{
  protected $primaryKey = ['id'];
  protected $fillable = ['id','nama','tanggal_lahir','jenis_kelamin'];
  public function periksa(){
    return $this->hasMany('App\Periksa');
      }
}
